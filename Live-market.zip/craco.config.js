/* craco.config.js */
module.exports = {
  // ...
};
