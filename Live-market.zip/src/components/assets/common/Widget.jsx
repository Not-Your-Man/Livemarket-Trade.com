const Widget = () => {
  return (
    <coingecko-coin-price-marquee-widget
      coin-ids="bitcoin,ethereum,eos,ripple,litecoin"
      currency="usd"
      background-color="#000000"
      locale="en"
    ></coingecko-coin-price-marquee-widget>
  );
};

export default Widget;
